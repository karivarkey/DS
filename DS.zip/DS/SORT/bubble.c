#include<stdio.h>



void bubble(int a[],int size)
{
  for(int i=0; i<size; i++)
  {
    for(int j=0 ; j < size-i-1; j++)
    {
      if (a[j] > a[j+1])
      {
        int temp = a[j];
        a[j] = a[j+1];
        a[j+1] = temp;
      }
    }
  }
}



void main()
{
    int size;
    printf("Enter the size of the arrat : ");
    scanf("%d",&size);
    int array[size];
    for (int i=0 ; i<size;i++)
    {
        printf("Enter the value at %d : ",i);
        scanf("%d",&array[i]);
    }
    bubble(array,size);
    printf("SORTED\n");
    for (int i=0 ; i<size;i++)
    {
        printf("|%d|",array[i]);
    }
}
