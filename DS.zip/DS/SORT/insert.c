#include<stdio.h>


void insert(int a[],int size)
{
  int i , key ,j;
  for (int i=1;i<size;i++)
  {
    key = a[i];
    j = i-1;
    while (j>=0 && a[j] > key)
    {
      a[j +1] = a[j];
      j = j-1;
    }
    a[j+1]=key;
  }
    for (i=0;i<size;i++){
    printf("|%d|",a[i]);
  }
}

void main()
{
  int size;
  printf("Enter the size of the array : ");
  scanf("%d",&size);
  int array[size];
  for (int i=0;i<size;i++){
    printf("Enter the value at %d : ",i);
    scanf("%d",&array[i]);
  }
  insert(array,size);
  
}
