#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024  // Size of the shared memory segment

int main() {
    key_t key = ftok("shmfile", 65);  // Generate a unique key
    int shmid = shmget(key, SHM_SIZE, 0666|IPC_CREAT);  // Create a shared memory segment

    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }

    char *data = (char*) shmat(shmid, (void*)0, 0);  // Attach the segment to our data space
    if (data == (char*)(-1)) {
        perror("shmat failed");
        exit(1);
    }

    printf("Write Data: ");
    fgets(data, SHM_SIZE, stdin);  // Get input from the user and write it to the shared memory

    printf("Data written to shared memory: %s\n", data);

    if (shmdt(data) == -1) {  // Detach the shared memory segment
        perror("shmdt failed");
        exit(1);
    }

    return 0;
}
