#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFFER_SIZE 10

typedef struct {
    int buffer[BUFFER_SIZE];
    volatile int in;
    volatile int out;
} circular_buffer;

circular_buffer cb = {{0}, 0, 0}; // Initialize circular buffer
sem_t empty, full, mutex;          // Declare semaphores

void produce(circular_buffer *cb, int item) {
    cb->buffer[cb->in] = item;
    cb->in = (cb->in + 1) % BUFFER_SIZE;
}

int consume(circular_buffer *cb) {
    int item = cb->buffer[cb->out];
    cb->out = (cb->out + 1) % BUFFER_SIZE;
    return item;
}

void* producer(void* arg) {
    int item;
    for (int i = 0; i < 20; i++) {
        item = rand() % 100; // Produce an item

        sem_wait(&empty); // Decrement empty count
        sem_wait(&mutex); // Enter critical section

        produce(&cb, item);
        printf("Produced: %d\n", item);

        sem_post(&mutex); // Leave critical section
        sem_post(&full);  // Increment full count

        sleep(rand() % 2); // Sleep for a random time
    }
    pthread_exit(NULL);
}

void* consumer(void* arg) {
    int item;
    for (int i = 0; i < 20; i++) {
        sem_wait(&full);  // Decrement full count
        sem_wait(&mutex); // Enter critical section

        item = consume(&cb);
        printf("Consumed: %d\n", item);

        sem_post(&mutex); // Leave critical section
        sem_post(&empty); // Increment empty count

        sleep(rand() % 2); // Sleep for a random time
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t prod, cons;

    // Initialize semaphores
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);
    sem_init(&mutex, 0, 1);

    // Create producer and consumer threads
    pthread_create(&prod, NULL, producer, NULL);
    pthread_create(&cons, NULL, consumer, NULL);

    // Wait for both threads to finish
    pthread_join(prod, NULL);
    pthread_join(cons, NULL);

    // Destroy semaphores
    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&mutex);

    return 0;
}
