#ifndef PRODCONS_H
#define PRODCONS_H

#define BUFFER_SIZE 10

// Circular buffer
typedef struct {
    int buffer[BUFFER_SIZE];
    int in;
    int out;
} circular_buffer;

void produce(circular_buffer *cb, int item);
int consume(circular_buffer *cb);

#endif
