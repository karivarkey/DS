#!/bin/bash

echo "Enter the number : "
read num
sum=1
while [ $num -gt 0 ]; do
    sum=$((sum * num))
    num=$((num-1))
done
echo $sum