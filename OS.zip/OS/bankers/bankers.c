#include<stdio.h>

void calculateNeed(int need[][10],int max[][10],int allot[][10],int P,int R);
int isSafe(int processes[], int avail[], int max[][10], int allot[][10], int P, int R);



void calculateNeed(int need[][10],int max[][10],int allot[][10],int P,int R){
    for (int i=0; i<= P ; i++)
    {
        for (int j=0; i < R;j++){
            need[i][j] = max[i][j] - allot[i][j];
        } 
    }
}


int isSafe(int processes[], int avail[], int max[][10], int allot[][10], int P, int R){
    int need[10][10];
    calculateNeed(need,max,allot,P,R);

    int finish[P];
    for (int i=0; i<P; i++){
        finish[i] = 0;
    }

    int safeSequence[P];
    int work[R];
    for (int i=0; i<R ;i++){
        work[i] = avail[i];
    }


    int count = 0;
    while (count < P){
        int found = 0;
        for ( int p=0; p<P ;p++ ){
            if (finish[p] == 0){
                for (int j=0; j<R; j++){
                    if (need[p][j] > work[j]){
                        break;
                    }
                }

                if (j==R){
                    for (int k=0; k<R; k++){
                        work[k] += allot[p][k];
                    }
                    safeSequence[count++] = processes[p];
                    finish[p]=1;
                    found = 1;
                }
            }
        }
        if (found == 0){
            printf("System deteced a deadlock");
            return 0;
        }
    }
}