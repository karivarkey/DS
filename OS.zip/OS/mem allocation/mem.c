#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h.>

struct MemoryBlock{
    int size;
    bool isFree;
    struct MemoryBlock* next;
};

typedef struct MemoryBlock MemoryBlock;

MemoryBlock* createBlock(int size){
    MemoryBlock* block = (MemoryBlock *)malloc(sizeof(MemoryBlock));
    block->size = size;
    block->isFree = true;
    block->next = NULL;
    return block;
}

void addBlock(MemoryBlock** head,int size){
    MemoryBlock* newBlock = createBlock(size);
    newBlock->next = *head;
    *head = newBlock;
}


void printBlock(MemoryBlock* head){
    MemoryBlock* temp = head;
    while (temp!= NULL){
        printf("Block size : %d, %s\n",temp->size,temp->isFree);
        temp = temp->next;
    }
    printf("\n");
}



void worstFit(MemoryBlock* head,int size){
    MemoryBlock *temp = head;
    while (temp !=NULL){
        if (temp->isFree && temp->size > size){
            temp->isFree = false;
            printf("Allocated %d bytes using first fite\n",size);
            return;
        }
        temp = temp->next;
    }
}


void bestFit(MemoryBlock* head,int size){
    MemoryBlock *temp = head;
    MemoryBlock *beastBlock = NULL;
    while (temp != NULL){
        if (temp->isFree && temp->size >size){
            if (beastBlock == NULL || temp->size < beastBlock->size){
                beastBlock = temp;
            }
        }
        temp = temp->next;
    }
    if (beastBlock != NULL){
        beastBlock->isFree = false;
        printf("Allocated %d bytes using best-fit",size);
    }else{
        printf("No location found when trying to allocate %d using best-fit",size);
    }
}


void worstFit(MemoryBlock *head,int size){
    MemoryBlock *temp = head;
    MemoryBlock *worstBlock = NULL;
    while (temp !=NULL){
        if (temp->isFree && temp->size > size){
            if (worstBlock == NULL || temp->size > worstBlock->size){
                worstBlock = temp;
            }
        }
    }
    if (worstBlock != NULL){
        worstBlock->isFree = false;
        printf("Allocated %d using worst-fit",size);
    }else{
        printf("%d cannot be allocated in worst-fit",size);
    }
}
