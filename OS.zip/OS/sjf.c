#include<stdio.h>
#include<stdlib.h>

struct sjf {
    int at;
    int bt;
    int ct;
    int tat;
    int wt;
    int pid;
} p[20], temp;

void atsort(int n) {
    for(int i = 0; i < n; i++) {
        for(int j = i + 1; j < n; j++) {
            if(p[i].at > p[j].at) { 
                temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }
}

void sjf(int n) {
    atsort(n); 
    int completed = 0, currentTime = 0;
    while(completed < n) {
        int minIndex = -1;
        int minBurst = 99999;
        for(int i = 0; i < n; i++) {
            if(p[i].at <= currentTime && p[i].ct == 0 && p[i].bt < minBurst) {
                minBurst = p[i].bt;
                minIndex = i;
            }
        }
        if(minIndex == -1) {
            currentTime++;
            continue;
        }
        p[minIndex].ct = currentTime + p[minIndex].bt;
        currentTime += p[minIndex].bt;
        completed++;
    }

    // Calculate turnaround time and waiting time
    for(int i = 0; i < n; i++) {
        p[i].tat = p[i].ct - p[i].at;
        p[i].wt = p[i].tat - p[i].bt;
    }
}

void main() {
    int n;
    printf("Enter the number of processes = ");
    scanf("%d", &n);

    for(int i = 0; i < n; i++) {
        printf("Enter process id: ");
        scanf("%d", &p[i].pid);
        printf("Enter the arrival time: ");
        scanf("%d", &p[i].at);
        printf("Enter the burst time: ");
        scanf("%d", &p[i].bt);
        p[i].ct = 0; // Initialize completion time to 0
    }

    sjf(n);

    printf("pid\tAt\tbt\tct\tTAT\tWT\n");
    for(int i = 0; i < n; i++) {
        printf(" %d \t %d \t %d \t %d \t %d \t %d\n", p[i].pid, p[i].at, p[i].bt, p[i].ct, p[i].tat, p[i].wt);
    }
}
