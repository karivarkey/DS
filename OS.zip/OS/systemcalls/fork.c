#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main()
{
    pid_t pid;
    pid = fork();


    if ( pid < 0 ) {
        printf("Fork failed");
    }
    else if(pid == 0) {
            printf("This is the child process with PID : %d\n",getpid());
    } else {
        printf("This is the parent process with PID : %d",getpid());
    }
    return 0;
}