#include<stdio.h>


void search(int a[],int size,int key)
{
    int flag = 0;
    for (int i=0;i<size;i++)
    {
        if (a[i] == key)
        {
            flag = 1;
            printf("%d found at %d\n",key,i);
        }
    }
    if (flag ==0)
    {
        printf("Element not found");
    }
}

void main()
{
    int size,key;
    printf("Enter the size of the array : ");
    scanf("%d",&size);
    int array[size];
    for (int i=0 ; i<size; i++)
    {
        printf("Enter the value at %d : ",i);
        scanf("%d",&array[i]);
    }
    printf("Enter the ket to search : ");
    scanf("%d",&key);
    search(array,size,key);
}