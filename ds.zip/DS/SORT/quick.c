#include <stdio.h>

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int pivot(int a[], int low, int high)
{
    int pivot = a[high];
    int i = low - 1;
    for (int j = low; j <= high - 1; j++)
    {
        if (a[j] < pivot)
        {
            i++;
            swap(&a[i], &a[j]);
        }
    }
    swap(&a[i + 1], &a[high]);
    return i + 1;
}

void quick(int a[], int low, int high)
{
    if (low < high)
    {
        int pi = pivot(a, low, high);

        quick(a, low, pi - 1);
        quick(a, pi + 1, high);
    }
}

int main()
{
    int size;
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    int array[size];
    for (int i = 0; i < size; i++)
    {
        printf("Enter the value at %d: ", i);
        scanf("%d", &array[i]);
    }
    quick(array, 0, size - 1);
    printf("SORTED\n");
    for (int i = 0; i < size; i++)
    {
        printf("|%d|", array[i]);
    }
    return 0;
}

