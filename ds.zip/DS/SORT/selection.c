#include<stdio.h>
void selection(int a[],int size)
{
  for (int i=0; i<size-1; i++)
  {
    int min_index = i;
    for (int j=i+1 ; j<size; j++)
    {
      if (a[j] < a[min_index])
      {
        min_index = j;
      }
    }
    int temp = a[i];
    a[i] = a[min_index];
    a[min_index] = temp;
  }
  
  
  
}

void main()
{
    int size;
    printf("Enter the size of the arrat : ");
    scanf("%d",&size);
    int array[size];
    for (int i=0 ; i<size;i++)
    {
        printf("Enter the value at %d : ",i);
        scanf("%d",&array[i]);
    }
    selection(array,size);
    printf("SORTED\n");
    for (int i=0 ; i<size;i++)
    {
        printf("|%d|",array[i]);
    }
}
