#include <stdio.h>
#include <stdlib.h>

// Define a structure for a tree node
struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

// Function to create a new node with a given key
struct Node* createNode(int key) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = key;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Function to insert a key into the BST
struct Node* insert(struct Node* root, int key) {
    // Base case: if the tree is empty, return a new node
    if (root == NULL)
        return createNode(key);

    // Otherwise, recur down the tree
    if (key < root->data)
        root->left = insert(root->left, key);
    else if (key > root->data)
        root->right = insert(root->right, key);

    // Return the unchanged node pointer
    return root;
}

// Function to perform inorder traversal of the BST
void inorderTraversal(struct Node* root) {
    if (root != NULL) {
        inorderTraversal(root->left);
        printf("%d ", root->data);
        inorderTraversal(root->right);
    }
}

// Function to search for a key in the BST
struct Node* search(struct Node* root, int key) {
    // Base cases: root is null or key is present at the root
    if (root == NULL || root->data == key)
        return root;

    // Key is greater than root's key, search in the right subtree
    if (key > root->data)
        return search(root->right, key);

    // Key is smaller than root's key, search in the left subtree
    return search(root->left, key);
}

int main() {
    struct Node* root = NULL;
    
    // Insert elements into the BST
    root = insert(root, 50);
    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);

    // Print inorder traversal of the BST
    printf("Inorder traversal of the BST: ");
    inorderTraversal(root);
    printf("\n");

    // Search for a key in the BST
    int keyToSearch = 40;
    struct Node* result = search(root, keyToSearch);
    if (result != NULL)
        printf("%d found in the BST.\n", keyToSearch);
    else
        printf("%d not found in the BST.\n", keyToSearch);

    // Deallocate memory (optional)
    // Note: In a real-world scenario, you would need to free the memory properly.
    
    return 0;
}
