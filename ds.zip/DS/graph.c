#include <stdio.h>
#include <stdlib.h>

// Maximum number of vertices in the graph
#define MAX_VERTICES 10

// Structure to represent a graph
typedef struct Graph {
    int vertices;
    int edges;
    int adjacencyMatrix[MAX_VERTICES][MAX_VERTICES];
    struct Node* adjacencyList[MAX_VERTICES];
} Graph;

// Structure to represent a node in the adjacency list
typedef struct Node {
    int vertex;
    struct Node* next;
} Node;

// Function to initialize a graph
void initializeGraph(Graph* graph, int vertices) {
    graph->vertices = vertices;
    graph->edges = 0;

    // Initialize adjacency matrix with all zeros
    for (int i = 0; i < MAX_VERTICES; i++) {
        for (int j = 0; j < MAX_VERTICES; j++) {
            graph->adjacencyMatrix[i][j] = 0;
        }
    }

    // Initialize adjacency list with NULL
    for (int i = 0; i < MAX_VERTICES; i++) {
        graph->adjacencyList[i] = NULL;
    }
}

// Function to add an edge to the graph
void addEdge(Graph* graph, int start, int end) {
    // Update adjacency matrix
    graph->adjacencyMatrix[start][end] = 1;
    graph->adjacencyMatrix[end][start] = 1;

    // Update adjacency list
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->vertex = end;
    newNode->next = graph->adjacencyList[start];
    graph->adjacencyList[start] = newNode;

    newNode = (Node*)malloc(sizeof(Node));
    newNode->vertex = start;
    newNode->next = graph->adjacencyList[end];
    graph->adjacencyList[end] = newNode;

    graph->edges++;
}

// Function to perform Breadth-First Search (BFS)
void BFS(Graph* graph, int start) {
    // TODO: Implement BFS
}

// Recursive function for Depth-First Search (DFS)
void DFSUtil(Graph* graph, int vertex, int visited[]) {
    // TODO: Implement DFS
}

// Function to perform Depth-First Search (DFS)
void DFS(Graph* graph, int start) {
    // Initialize an array to keep track of visited vertices
    int visited[MAX_VERTICES];
    for (int i = 0; i < MAX_VERTICES; i++) {
        visited[i] = 0;
    }

    // Call the recursive DFS function
    DFSUtil(graph, start, visited);
}

// Function to print the adjacency matrix of the graph
void printAdjacencyMatrix(Graph* graph) {
    printf("Adjacency Matrix:\n");
    for (int i = 0; i < graph->vertices; i++) {
        for (int j = 0; j < graph->vertices; j++) {
            printf("%d ", graph->adjacencyMatrix[i][j]);
        }
        printf("\n");
    }
}

// Function to print the adjacency list of the graph
void printAdjacencyList(Graph* graph) {
    printf("Adjacency List:\n");
    for (int i = 0; i < graph->vertices; i++) {
        printf("Vertex %d: ", i);
        Node* current = graph->adjacencyList[i];
        while (current != NULL) {
            printf("%d ", current->vertex);
            current = current->next;
        }
        printf("\n");
    }
}

int main() {
    Graph graph;
    int vertices, edges;
    
    printf("Enter the number of vertices (max %d): ", MAX_VERTICES);
    scanf("%d", &vertices);

    initializeGraph(&graph, vertices);

    printf("Enter the number of edges: ");
    scanf("%d", &edges);

    printf("Enter the edges (vertex pairs):\n");
    for (int i = 0; i < edges; i++) {
        int start, end;
        scanf("%d %d", &start, &end);
        addEdge(&graph, start, end);
    }

    printAdjacencyMatrix(&graph);
    printAdjacencyList(&graph);

    // Choose a starting vertex for BFS and DFS
    int startVertex;
    printf("Enter the starting vertex for BFS and DFS: ");
    scanf("%d", &startVertex);

    printf("BFS Traversal starting from vertex %d:\n", startVertex);
    BFS(&graph, startVertex);

    printf("DFS Traversal starting from vertex %d:\n", startVertex);
    DFS(&graph, startVertex);

    return 0;
}
